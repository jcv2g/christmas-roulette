SIMPLE SECRET CHRISTMAS ROULETTE

This is a static, no-backend version. It uses browser-side randomization and individual reveal links.

HOW TO USE
1. Open index.html in a browser to test it.
2. The organizer edits the participant list (one name per line).
3. Click Generate private links.
4. Copy each participant's link and send it only to that person.
5. Participants open their link to see their assigned recipient.

HOST ON GITHUB PAGES
1. Create a GitHub repository (e.g. secret-christmas-roulette).
2. Upload index.html to the repository root.
3. Open Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch, branch main, folder /(root), then Save.
5. Wait for the published URL and open it.
6. Generate the draw from the published URL, not from a local file, so generated links point to the hosted site.

IMPORTANT LIMITATIONS
- There is no database, login, PIN, or reveal tracking.
- A link reveals one recipient and should be sent privately. Anyone who gets or forwards that link can see that assignment.
- The draw is generated in the organizer's browser. Save the downloaded CSV privately as a backup.
- Do not regenerate after sending links, or the new draw will differ from the links already sent.
- The link itself is not cryptographically protected; this is suitable for a casual, trust-based gift exchange, not confidential or high-security use.
